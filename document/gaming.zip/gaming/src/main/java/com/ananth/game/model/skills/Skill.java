package com.ananth.game.model.skills;

public interface Skill {
}
