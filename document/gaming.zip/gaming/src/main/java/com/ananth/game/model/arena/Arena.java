package com.ananth.game.model.arena;

public interface Arena {

    void drawBackground();
}
