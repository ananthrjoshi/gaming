package com.ananth.game.model.arena;

public interface ArenaFactory {

    public Arena createArena();
}
