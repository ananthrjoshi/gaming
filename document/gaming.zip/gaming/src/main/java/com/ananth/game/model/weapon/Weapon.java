package com.ananth.game.model.weapon;

import java.io.Serializable;

public abstract class Weapon implements Serializable{

    void hit() {

    }
}
